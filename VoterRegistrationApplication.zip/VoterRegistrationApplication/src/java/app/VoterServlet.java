package app;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class VoterServlet extends HttpServlet {
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException 
    {
        
        String id = request.getParameter("id");
        String name = request.getParameter("name");
        String age = request.getParameter("age");
        String address = request.getParameter("address");
        
        try {
            addVoterData(id, name, age, address);
            response.sendRedirect("display.jsp");
        } catch (SQLException e) {
            throw new ServletException("Database error", e);
        }
    }

    private void addVoterData(String id, String name, String age, String address) throws SQLException {
        try (Connection conn = ConnectionProvider.getConnection();
            PreparedStatement stmt = conn.prepareStatement("INSERT INTO voters (id, name, age, address) VALUES (?, ?, ?, ?)")) 
        {
            stmt.setString(1, id);
            stmt.setString(2, name);
            stmt.setString(3, age);
            stmt.setString(4, address);
            stmt.executeUpdate();
        }
    }

    public ResultSet fetchData() throws SQLException {
        Connection conn = ConnectionProvider.getConnection();
        String sql = "SELECT * FROM voters";
        PreparedStatement stmt = conn.prepareStatement(sql);
        return stmt.executeQuery();
    }
}

