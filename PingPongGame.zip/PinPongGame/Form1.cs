﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PinPongGame
{
    public partial class Form1 : Form
    {
        int XballSpeeed = 4;
        int YballSpeeed = 4;
        int[] ballSpeed = { 10, 9, 8, 11, 12 };

        int speed = 2;
        Random ra = new Random();//assign it to the speed arrays so the ball and comp can change speeds
        bool down, up;

        int compSpeedChange = 50;
        int []compSpeed = { 5, 6, 8, 9};

        int playerScore = 0;
        int compScore = 0;

        int playerSpeed = 8;

        public Form1()
        {
            InitializeComponent();
        }

        private void gameTimerEvent(object sender, EventArgs e)
        {
            ball.Top -= YballSpeeed;
            ball.Left -= XballSpeeed;

            this.Text = "You" + playerScore + " - " + compScore+ " COM";

            if (ball.Top < 0| ball.Bottom > this.ClientSize.Height)//checking if the ball reaches the top or bottom of the screen
            {
                YballSpeeed = -YballSpeeed;//the ball will then bounce off the boarders and go in the oppopsite direction
            }

            if (ball.Left < -2)//checking if comp scores
            {
                ball.Left = 300;
                XballSpeeed = -XballSpeeed;
                compScore++;
            }

            else if(ball.Right > this.ClientSize.Width + 2)//checking if player scores
            {

                ball.Left = 300;
                XballSpeeed = -XballSpeeed;
                playerScore++;
            }

            if(COM.Top <= 1)//keeping the COM picture box in the screen
            {
                COM.Top =- COM.Top;
            }

            else if(COM.Bottom >= this.ClientSize.Height)
            {
                COM.Top = this.ClientSize.Height - COM.Height;
            }

            if(ball.Top < COM.Top + (COM.Height /2) && ball.Left > 300)///controlling the COMputer movements depnding on where the ball is halfway
            {
                COM.Top =- speed;//* 
            }

            if (ball.Top > COM.Top + (COM.Height / 2) && ball.Left > 2)//controlling the COMputer movements depnding on where the ball is halfway
            {
                COM.Top =+ speed;//*
            }

            compSpeedChange = -1;//decreasing the speed change

            if(compSpeedChange < 0)//when the sepped reaches 0 it'll pick a random value in the array
            {
                speed = compSpeed[ra.Next(compSpeed.Length)];
                compSpeedChange = 50;//reseting the change back to 50
            }

            if(down && player.Top + player.Height < this.ClientSize.Height)
            {
                player.Top += playerSpeed;
            }

            if(up && player.Top > 0)
            {
                player.Top -= playerSpeed;
            }

            checkBump(player.Right + + 5, ball, player);//setting up what actually happens when the ball hits the player
            checkBump(COM.Left - 35, ball, COM);//seting up what actually happens when the ball hits the computer

            if(playerScore == 5)
            {
                fullTime("You Win, +3");
            }

            else if(compScore == 5)
            {
                fullTime("You Lose...");
            }

            /*else if(playerScore == compScore)
            {
                fullTime("Draw, +1");
            }*/

        }

        private void KeyIsDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Down)
            {
                down = true;
            }

            if (e.KeyCode == Keys.Up)
            {
                up = true;
            }
        }

        private void KeyIsUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Down)
            {
                down = false;
            }

            if (e.KeyCode == Keys.Up)
            {
                up = false;
            }
        }

        private void checkBump(int offset, PictureBox pic1, PictureBox pic2)
        {
            //when the ball hits
            if (pic1.Bounds.IntersectsWith(pic2.Bounds))
            {
                pic1.Left = offset;//offet func is going to be given by the function, where the ball is gonna go after hit

                int x = ballSpeed[ra.Next(ballSpeed.Length)];
                int y = ballSpeed[ra.Next(ballSpeed.Length)];

                if (XballSpeeed < 0)//moving towards the left less than 0, moving towards tyhe roght greater than 0
                {
                    XballSpeeed = x;
                }

                else//basically if the the player hits the ball we want the ball to go right and if the comp hits the ball we want it to goo left
                {
                    XballSpeeed = -x;
                }

                if (YballSpeeed < 0)//
                {
                    YballSpeeed = -y;
                }

                else//
                {
                    YballSpeeed = y;
                }

                
            }
        }

        private void fullTime(string message)
        {
            //gameTimer = new Timer();
            gameTimer.Stop();
            MessageBox.Show(message, "Full Time!!");
            
            compScore = 0;
            playerScore = 0;

            XballSpeeed = 4;
            YballSpeeed = 4;
            compSpeedChange = 50;

            gameTimer.Start();

        }

    }
}
