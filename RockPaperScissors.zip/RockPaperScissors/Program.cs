﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RockPaperScissors
{
    class Program
    {
        static void Main(string[] args)
        {
            string player, COM;
            int random;
            int playerScore = 0, COMScore = 0;

            Console.WriteLine("----------ROCK, PAPER, SCISSORS----------");
            Console.WriteLine("Choose between Rock, Paper or Scissors(Pres e to exit): ");

            player = Console.ReadLine();
            player = player.ToUpper();

            Random rand = new Random();
            random = rand.Next(1, 4);

            bool rematch = true;

            while (rematch)
            {
                while (playerScore < 3 && COMScore < 3)
                {
                    if (player.Equals("e".ToUpper()))
                    {
                        Environment.Exit(0);
                    }

                    switch (random)
                    {
                        case 1:
                            COM = "Rock".ToUpper();
                            Console.WriteLine("COM chose Rock");

                            if (player == "ROCK")
                            {
                                Console.WriteLine("DRAW!! \n\n");
                            }

                            else if (player == "PAPER")
                            {
                                Console.WriteLine("YOU WIN!! \n\n");
                                playerScore++;
                            }

                            else if (player == "SCISSORS")
                            {
                                Console.WriteLine("COM WINS!! \n\n");
                                COMScore++;
                            }

                            break;

                        case 2:
                            COM = "Paper".ToUpper();
                            Console.WriteLine("COM chose Paper");

                            if (player == "ROCK")
                            {
                                Console.WriteLine("COM WINS!! \n\n");
                                COMScore++;
                            }

                            else if (player == "PAPER")
                            {
                                Console.WriteLine("DRAW!! \n\n");
                            }

                            else if (player == "SCISSORS")
                            {
                                Console.WriteLine("YOU WIN!! \n\n");
                                playerScore++;
                            }

                            break;

                        case 3:
                            COM = "Scissors".ToUpper();
                            Console.WriteLine("COM chose Scissors");

                            if (player == "ROCK")
                            {
                                Console.WriteLine("YOU WIN!! \n\n");
                                playerScore++;
                            }

                            else if (player == "PAPER")
                            {
                                Console.WriteLine("COM WINS!! \n\n");
                                COMScore++;
                            }

                            else if (player == "SCISSORS")
                            {
                                Console.WriteLine("DRAW!! \n\n");
                            }

                            break;

                        default:
                            Console.WriteLine("Invalid Entry");
                            break;
                    }
                }

                if (playerScore == 3)
                {
                    Console.WriteLine("YOU WIN!!");
                }

                else if (COMScore == 3)
                {
                    Console.WriteLine("COM WINS!!");
                }

                Console.WriteLine("Play again(Y/N)?");
                String again = Console.ReadLine();

                if (again.Equals("Y".ToUpper()))
                {
                    rematch = true;
                }

                else if (again.Equals("N".ToUpper()))
                {
                    rematch = false;
                    Environment.Exit(0);
                }
            }

        }
    }
}
