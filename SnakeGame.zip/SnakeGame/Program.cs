﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace SnakeGame
{
    class Program
    {
        static void Main(string[] args)
        {

            Board dimensions = new Board(50, 20);

            Board snakePos = new Board(10, 2);
           
            Random rand = new Random();

            Board fruitPos = new Board(rand.Next(1, dimensions.X - 1), rand.Next(1, dimensions.Y - 1));

            int score = 0;

            //snake movement
            int frameDelay = 100;
            SnakeDirections movement = SnakeDirections.DOWN;

            //snake tail positioning
            List<Board> snakeHistory = new List<Board>();
            int tailLength = 1;

            while (true)
            {
                Console.Clear();
                Console.WriteLine("Score: " + score);
                snakePos.movementDirection(movement);

                //playing field
                for (int y = 0; y < dimensions.Y; y++)
                {
                    for (int x = 0; x < dimensions.X; x++)
                    {
                        Board current = new Board(x, y);

                        if (snakePos.Equals(current) || snakeHistory.Contains(current))//snake head and snake body
                        {
                            Console.Write("0");
                        }

                        else if (fruitPos.Equals(current))//fruit spawning
                        {
                            Console.Write("a");
                        }

                        else if (x == 0 && y == 0 || dimensions.X - 1 == x && dimensions.Y - 1 == y)
                        {
                            Console.Write("#");
                        }

                        else
                        {
                            Console.Write(" ");
                        }

                        Console.WriteLine();
                    }
                }

                if(snakePos.Equals(fruitPos))
                {
                    tailLength++;//tail increases when fruit is ate
                    score++;//score increases when fruit is ate
                    fruitPos = new Board(rand.Next(1, dimensions.X - 1), rand.Next(1, dimensions.Y - 1));//putting the fruit somewhere random after the snake eats it
                }

                else if(snakePos.X == 0 || snakePos.Y == 0 || snakePos.X == dimensions.X - 1 || snakePos.Y == dimensions.Y - 1 || snakeHistory.Contains(snakePos)//resting the game
                {
                    score = 0;
                    tailLength = 1;
                    snakePos = new Board(10, 2);
                    snakeHistory.Clear();
                    movement = SnakeDirections.DOWN;
                    continue;
                }

                snakeHistory.Add(new Board(snakePos.X, snakePos.Y));

                if (snakeHistory.Count > tailLength)
                {
                    snakeHistory.RemoveAt(0);//remove from front of the list
                }

                //snakeHistory = snakeHistory.TakeLast(tailLength).ToList();

                DateTime time = DateTime.Now;

                while((DateTime.Now - time).TotalMilliseconds < frameDelay)
                {
                    if(Console.KeyAvailable)
                    {
                        ConsoleKey key = Console.ReadKey(true).Key;

                        switch(key)
                        {
                            case ConsoleKey.LeftArrow: movement = SnakeDirections.LEFT;
                                break;

                            case ConsoleKey.RightArrow: movement = SnakeDirections.RIGHT;
                                break;

                            case ConsoleKey.UpArrow: movement = SnakeDirections.UP;
                                break;

                            case ConsoleKey.DownArrow: movement = SnakeDirections.DOWN;
                                break;
                        }
                    }
                }
            }
  
        }
    }
}
