﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SnakeGame
{
    class Board
    {
        private int x, y;

        public int X
        {
            get { return x; }
        }

        public int Y
        {
            get { return y; }
        }

        public Board(int x, int y)
        {
            this.x = x;
            this.y = y;
        }

        public override bool Equals(object obj)
        {
            if(obj == null || GetType() != obj.GetType())
            {
                return false;
            }

            Board other = (Board)obj;
            return (x == other.x && y == other.y);
        }

        public void movementDirection(SnakeDirections directions)
        {
            switch(directions)
            {
                case SnakeDirections.UP: y--;
                    break;

                case SnakeDirections.DOWN: y++;
                    break;

                case SnakeDirections.LEFT: x--;
                    break;

                case SnakeDirections.RIGHT: x++;
                    break;
            }
        }
    }
}
