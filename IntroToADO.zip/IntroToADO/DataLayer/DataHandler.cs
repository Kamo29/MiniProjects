﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data;
using IntroToADO.Logic;

namespace IntroToADO.DataLayer
{
    class DataHandler
    {
        //String connect to database after creating it
        string conn = "Server = .;";//Server = ; Initial Catalog =   ; Integrated Security = ;
        DataTable tbl;
        SqlDataAdapter adapt;


        public void getStuData()
        {
            SqlConnection connect = new SqlConnection(conn);//connection object using the connection string

            string query = @"SELECT* FROM tblStudents";//enter the query you want
            adapt = new SqlDataAdapter(query, connect);//instantiated to connect with the database

            tbl = new DataTable();

            adapt.Fill(tbl);//filling in the tbl with the info            
        }

        public void regStu(Students students)
        {
            string query = $"INSERT INTO tblStudents VALUES ('{students.StudNum}, {students.Name}, {students.Surname}, {students.Course}, {students.Age}, {students.Phone}')";//enter the query you want

            try
            {
                using(SqlConnection connect = new SqlConnection(conn))//connection object using the connection string
                {
                    using(SqlCommand command = new SqlCommand(query, connect))
                    {
                        connect.Open();
                        command.ExecuteNonQuery();
                        connect.Close();
                    }
                }
            }

            catch (Exception e)
            {
                Console.WriteLine(e.Message);
                Console.WriteLine("Error in connecting to database");
            }
            
        }

        public void updateStu(Students students)
        {
            string query = $"UPDATE tblStudents SET studentAge = {students.Age} WHERE studentNumber = {students.StudNum}";//update query

            try
            {
                using (SqlConnection connect = new SqlConnection(conn))//connection object using the connection string
                {
                    using (SqlCommand command = new SqlCommand(query, connect))
                    {
                        connect.Open();
                        command.ExecuteNonQuery();
                        connect.Close();
                    }
                }
            }

            catch(Exception e)
            {
                Console.WriteLine(e.Message);
            }
        }

        public void deleteStu(Students students)
        {
            string query = $"DELETE* FROM tblStudents WHERE studentNumber = {students.StudNum}";

            try
            {
                using (SqlConnection connect = new SqlConnection(conn))//connection object using the connection string
                {
                    using (SqlCommand command = new SqlCommand(query, connect))
                    {
                        connect.Open();
                        command.ExecuteNonQuery();
                        connect.Close();
                    }
                }
            }

            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
        }

        public DataTable search(int studNum)//we dont need to access the database, the datatable is a copy of the database
        {
            string query = @"SELECT...";//search for stuff

            adapt = new SqlDataAdapter(query, conn);

            tbl = new DataTable();

            adapt.Fill(tbl);

            return tbl;
        }
    }
}
