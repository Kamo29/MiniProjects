﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using IntroToADO.PresentationLayer;

namespace IntroToADO.PresentationLayer
{
    public partial class MainPage : Form
    {
        public MainPage()
        {
            InitializeComponent();
        }

        private void displayBttn_Click(object sender, EventArgs e)
        {
            //going to the display form
            DisplayStudents ds = new DisplayStudents();
            ds.Show();
            this.Hide();

        }
    }
}
