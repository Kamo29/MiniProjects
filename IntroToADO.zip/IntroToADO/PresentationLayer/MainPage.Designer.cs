﻿
namespace IntroToADO.PresentationLayer
{
    partial class MainPage
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.nameTxt = new System.Windows.Forms.TextBox();
            this.snameTxt = new System.Windows.Forms.TextBox();
            this.ageTxt = new System.Windows.Forms.TextBox();
            this.phoneTxt = new System.Windows.Forms.TextBox();
            this.stuNumTxt = new System.Windows.Forms.TextBox();
            this.courseTxt = new System.Windows.Forms.TextBox();
            this.regBttn = new System.Windows.Forms.Button();
            this.displayBttn = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(32, 67);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(45, 17);
            this.label1.TabIndex = 0;
            this.label1.Text = "Name";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(32, 103);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(65, 17);
            this.label2.TabIndex = 1;
            this.label2.Text = "Surname";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(32, 194);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(49, 17);
            this.label3.TabIndex = 2;
            this.label3.Text = "Phone";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(32, 238);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(111, 17);
            this.label4.TabIndex = 3;
            this.label4.Text = "Student Number";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(32, 147);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(33, 17);
            this.label5.TabIndex = 4;
            this.label5.Text = "Age";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(32, 282);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(53, 17);
            this.label6.TabIndex = 5;
            this.label6.Text = "Course";
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.Size = new System.Drawing.Size(61, 4);
            // 
            // nameTxt
            // 
            this.nameTxt.Location = new System.Drawing.Point(211, 64);
            this.nameTxt.Name = "nameTxt";
            this.nameTxt.Size = new System.Drawing.Size(174, 22);
            this.nameTxt.TabIndex = 7;
            // 
            // snameTxt
            // 
            this.snameTxt.Location = new System.Drawing.Point(211, 103);
            this.snameTxt.Name = "snameTxt";
            this.snameTxt.Size = new System.Drawing.Size(174, 22);
            this.snameTxt.TabIndex = 8;
            // 
            // ageTxt
            // 
            this.ageTxt.Location = new System.Drawing.Point(211, 147);
            this.ageTxt.Name = "ageTxt";
            this.ageTxt.Size = new System.Drawing.Size(174, 22);
            this.ageTxt.TabIndex = 9;
            // 
            // phoneTxt
            // 
            this.phoneTxt.Location = new System.Drawing.Point(211, 191);
            this.phoneTxt.Name = "phoneTxt";
            this.phoneTxt.Size = new System.Drawing.Size(174, 22);
            this.phoneTxt.TabIndex = 10;
            // 
            // stuNumTxt
            // 
            this.stuNumTxt.Location = new System.Drawing.Point(211, 235);
            this.stuNumTxt.Name = "stuNumTxt";
            this.stuNumTxt.Size = new System.Drawing.Size(174, 22);
            this.stuNumTxt.TabIndex = 11;
            // 
            // courseTxt
            // 
            this.courseTxt.Location = new System.Drawing.Point(211, 282);
            this.courseTxt.Name = "courseTxt";
            this.courseTxt.Size = new System.Drawing.Size(174, 22);
            this.courseTxt.TabIndex = 12;
            // 
            // regBttn
            // 
            this.regBttn.Location = new System.Drawing.Point(505, 116);
            this.regBttn.Name = "regBttn";
            this.regBttn.Size = new System.Drawing.Size(146, 48);
            this.regBttn.TabIndex = 13;
            this.regBttn.Text = "Register";
            this.regBttn.UseVisualStyleBackColor = true;
            // 
            // displayBttn
            // 
            this.displayBttn.Location = new System.Drawing.Point(505, 190);
            this.displayBttn.Name = "displayBttn";
            this.displayBttn.Size = new System.Drawing.Size(146, 48);
            this.displayBttn.TabIndex = 14;
            this.displayBttn.Text = "Display";
            this.displayBttn.UseVisualStyleBackColor = true;
            this.displayBttn.Click += new System.EventHandler(this.displayBttn_Click);
            // 
            // MainPage
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(794, 370);
            this.Controls.Add(this.displayBttn);
            this.Controls.Add(this.regBttn);
            this.Controls.Add(this.courseTxt);
            this.Controls.Add(this.stuNumTxt);
            this.Controls.Add(this.phoneTxt);
            this.Controls.Add(this.ageTxt);
            this.Controls.Add(this.snameTxt);
            this.Controls.Add(this.nameTxt);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "MainPage";
            this.Text = "MainPage";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
        private System.Windows.Forms.TextBox nameTxt;
        private System.Windows.Forms.TextBox snameTxt;
        private System.Windows.Forms.TextBox ageTxt;
        private System.Windows.Forms.TextBox phoneTxt;
        private System.Windows.Forms.TextBox stuNumTxt;
        private System.Windows.Forms.TextBox courseTxt;
        private System.Windows.Forms.Button regBttn;
        private System.Windows.Forms.Button displayBttn;
    }
}