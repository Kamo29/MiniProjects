﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using IntroToADO.DataLayer;
using System.IO;

namespace IntroToADO.PresentationLayer
{
    public partial class DisplayStudents : Form
    {
        public DisplayStudents()
        {
            InitializeComponent();
        }

        DataHandler dh = new DataHandler();

        private BindingSource bindingSource = new BindingSource();
        DataTable table;

        private void DisplayStudents_Load(object sender, EventArgs e)
        {
            string[] lines = File.ReadAllLines(@"");
            string[] values;

            for(int i = 0; i < lines.Length; i++)
            {
                values = lines[i].ToString().Split(';');
                string[] row = new string[values.Length];

                for(int j = 0; j < values.Length; j++)
                {
                    row[j] = values[j].Trim();
                }

                table.Rows.Add(row);
            }
        }



        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void searchBttn_Click(object sender, EventArgs e)
        {
            int searchNum = int.Parse(searchTxt.Text);

            //filtering the data based on the search text box
            var filteredData = dh.search(searchNum);

            dataGridView1.DataSource = filteredData;//updating the DataGridView to show the filtered data


        }
    }
}
