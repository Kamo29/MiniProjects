﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IntroToADO.Logic
{
    class Students
    {

        private string course;
        private int age;
        private string name;
        private string surname;
        private int phone;
        private int studNum;

        public Students(string name, string surname, string course, int phone, int studNum, int age)
        {
            this.Name = name;
            this.Surname = surname;
            this.Course = course;
            this.Phone = phone;
            this.StudNum = studNum;
            this.Age = age;
        }

        public string Name { get => name; set => name = value; }
        public string Surname { get => surname; set => surname = value; }
        public string Course { get => course; set => course = value; }
        public int Phone { get => phone; set => phone = value; }
        public int StudNum { get => studNum; set => studNum = value; }
        public int Age { get => age; set => age = value; }
    }

}
