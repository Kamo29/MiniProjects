﻿
namespace MilesStone1.PresentationLayer
{
    partial class StudentForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.nameTxt = new System.Windows.Forms.TextBox();
            this.surnameTxt = new System.Windows.Forms.TextBox();
            this.phoneTxt = new System.Windows.Forms.TextBox();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.dobTxt = new System.Windows.Forms.DateTimePicker();
            this.searchTxt = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.searchBttn = new System.Windows.Forms.Button();
            this.editBttn = new System.Windows.Forms.Button();
            this.Delete = new System.Windows.Forms.Button();
            this.addBttn = new System.Windows.Forms.Button();
            this.label5 = new System.Windows.Forms.Label();
            this.ModuleTxt = new System.Windows.Forms.TextBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.addressTxt = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 43);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(45, 17);
            this.label1.TabIndex = 0;
            this.label1.Text = "Name";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(12, 85);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(65, 17);
            this.label2.TabIndex = 1;
            this.label2.Text = "Surname";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(12, 138);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(87, 17);
            this.label3.TabIndex = 2;
            this.label3.Text = "Date of Birth";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(467, 43);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(103, 17);
            this.label4.TabIndex = 3;
            this.label4.Text = "Phone Number";
            // 
            // nameTxt
            // 
            this.nameTxt.Location = new System.Drawing.Point(124, 38);
            this.nameTxt.Name = "nameTxt";
            this.nameTxt.Size = new System.Drawing.Size(286, 22);
            this.nameTxt.TabIndex = 5;
            this.nameTxt.TextChanged += new System.EventHandler(this.nameTxt_TextChanged);
            // 
            // surnameTxt
            // 
            this.surnameTxt.Location = new System.Drawing.Point(124, 85);
            this.surnameTxt.Name = "surnameTxt";
            this.surnameTxt.Size = new System.Drawing.Size(286, 22);
            this.surnameTxt.TabIndex = 6;
            // 
            // phoneTxt
            // 
            this.phoneTxt.Location = new System.Drawing.Point(576, 43);
            this.phoneTxt.Name = "phoneTxt";
            this.phoneTxt.Size = new System.Drawing.Size(286, 22);
            this.phoneTxt.TabIndex = 7;
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(12, 240);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersWidth = 51;
            this.dataGridView1.RowTemplate.Height = 24;
            this.dataGridView1.Size = new System.Drawing.Size(1155, 201);
            this.dataGridView1.TabIndex = 9;
            this.dataGridView1.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick);
            // 
            // dobTxt
            // 
            this.dobTxt.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dobTxt.Location = new System.Drawing.Point(124, 138);
            this.dobTxt.Name = "dobTxt";
            this.dobTxt.Size = new System.Drawing.Size(107, 22);
            this.dobTxt.TabIndex = 10;
            // 
            // searchTxt
            // 
            this.searchTxt.Location = new System.Drawing.Point(124, 194);
            this.searchTxt.Name = "searchTxt";
            this.searchTxt.Size = new System.Drawing.Size(286, 22);
            this.searchTxt.TabIndex = 12;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(12, 199);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(53, 17);
            this.label6.TabIndex = 11;
            this.label6.Text = "Search";
            // 
            // searchBttn
            // 
            this.searchBttn.Location = new System.Drawing.Point(447, 199);
            this.searchBttn.Name = "searchBttn";
            this.searchBttn.Size = new System.Drawing.Size(122, 23);
            this.searchBttn.TabIndex = 13;
            this.searchBttn.Text = "Search";
            this.searchBttn.UseVisualStyleBackColor = true;
            this.searchBttn.Click += new System.EventHandler(this.searchBttn_Click);
            // 
            // editBttn
            // 
            this.editBttn.Location = new System.Drawing.Point(15, 470);
            this.editBttn.Name = "editBttn";
            this.editBttn.Size = new System.Drawing.Size(122, 23);
            this.editBttn.TabIndex = 14;
            this.editBttn.Text = "Edit";
            this.editBttn.UseVisualStyleBackColor = true;
            this.editBttn.Click += new System.EventHandler(this.editBttn_Click);
            // 
            // Delete
            // 
            this.Delete.Location = new System.Drawing.Point(193, 470);
            this.Delete.Name = "Delete";
            this.Delete.Size = new System.Drawing.Size(122, 23);
            this.Delete.TabIndex = 15;
            this.Delete.Text = "Delete";
            this.Delete.UseVisualStyleBackColor = true;
            // 
            // addBttn
            // 
            this.addBttn.Location = new System.Drawing.Point(370, 470);
            this.addBttn.Name = "addBttn";
            this.addBttn.Size = new System.Drawing.Size(122, 23);
            this.addBttn.TabIndex = 16;
            this.addBttn.Text = "Add";
            this.addBttn.UseVisualStyleBackColor = true;
            this.addBttn.Click += new System.EventHandler(this.addBttn_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(467, 83);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(54, 17);
            this.label5.TabIndex = 4;
            this.label5.Text = "Module";
            // 
            // ModuleTxt
            // 
            this.ModuleTxt.Location = new System.Drawing.Point(576, 85);
            this.ModuleTxt.Name = "ModuleTxt";
            this.ModuleTxt.Size = new System.Drawing.Size(286, 22);
            this.ModuleTxt.TabIndex = 8;
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(576, 133);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(286, 22);
            this.textBox1.TabIndex = 18;
            // 
            // addressTxt
            // 
            this.addressTxt.AutoSize = true;
            this.addressTxt.Location = new System.Drawing.Point(467, 133);
            this.addressTxt.Name = "addressTxt";
            this.addressTxt.Size = new System.Drawing.Size(60, 17);
            this.addressTxt.TabIndex = 17;
            this.addressTxt.Text = "Address";
            // 
            // StudentForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1194, 516);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.addressTxt);
            this.Controls.Add(this.addBttn);
            this.Controls.Add(this.Delete);
            this.Controls.Add(this.editBttn);
            this.Controls.Add(this.searchBttn);
            this.Controls.Add(this.searchTxt);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.dobTxt);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.ModuleTxt);
            this.Controls.Add(this.phoneTxt);
            this.Controls.Add(this.surnameTxt);
            this.Controls.Add(this.nameTxt);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "StudentForm";
            this.Text = "StudentForm";
            this.Load += new System.EventHandler(this.StudentForm_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox nameTxt;
        private System.Windows.Forms.TextBox surnameTxt;
        private System.Windows.Forms.TextBox phoneTxt;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.DateTimePicker dobTxt;
        private System.Windows.Forms.TextBox searchTxt;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Button searchBttn;
        private System.Windows.Forms.Button editBttn;
        private System.Windows.Forms.Button Delete;
        private System.Windows.Forms.Button addBttn;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox ModuleTxt;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label addressTxt;
    }
}