﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace MilesStone1.PresentationLayer
{
    public partial class LoginForm : Form
    {
        public LoginForm()
        {
            InitializeComponent();
        }

        private void LoginForm_Load(object sender, EventArgs e)
        {

        }

        string filePath = "Logins.txt";
        CreateTextFile(filePath);

        static void CreateTextFile(string filePath)
        {
            // Use StreamWriter to create or overwrite the file
            using (StreamWriter sw = new StreamWriter(filePath, false))
            {
  
            }
        }

        private void loginBttn_Click(object sender, EventArgs e)
        {
            //compare username and password to those in database/textfile
            string[] line = File.ReadAllLines(filePath);
            string[] values;

            for (int i = 0; i < line.Length; i++)
            {
                string[] row = new string[line.Length];

                for (int j = 0; j < line.Length; j++)
                {
                    row[j] = line[j].Trim();
                }
            }
        }

        static bool CanLogin(string username, string password, Dictionary<string, string> userCredentials)
        {
            // Check if the username exists
            if (userCredentials.TryGetValue(username, out string storedPassword))
            {
                // Check if the provided password matches the stored password
                return password == storedPassword;
            }

            return false;
        }

    }
}

