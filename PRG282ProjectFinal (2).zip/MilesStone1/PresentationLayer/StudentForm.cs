﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using MilesStone1.DataLayer;
using MilesStone1.DataAccessLayer;

namespace MilesStone1.PresentationLayer
{
    public partial class StudentForm : Form
    {
        public StudentForm()
        {
            InitializeComponent();
        }

        StudentClass sC = new StudentClass();
        DataHandler dh = new DataHandler();

        private void StudentForm_Load(object sender, EventArgs e)
        {
            dataGridView1.DataSource = dh.showStudentData();
        }

        private void searchBttn_Click(object sender, EventArgs e)
        {
            string search = searchTxt.Text;

            var filter = dh.search(sC.SName);

            dataGridView1.DataSource = dh.search(sC.SName);
        }

        private void editBttn_Click(object sender, EventArgs e)
        {
            List<StudentClass> students = new List<StudentClass>();
        }

        private void nameTxt_TextChanged(object sender, EventArgs e)
        {
            sC.SName = nameTxt.Text;
        }

        //private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        //{

        //}

        private void addBttn_Click(object sender, EventArgs e)
        {
            string name = nameTxt.Text;
            string sname = surnameTxt.Text;
            DateTime date = DateTime.Parse(dobTxt.Text);
            int phone = int.Parse(phoneTxt.Text);
            string adress = addressTxt.Text;
            string mc = ModuleTxt.Text;

            sC = new StudentClass(name, sname, date, phone, adress, mc);
            dh.addStudent(sC);


            dataGridView1.DataSource = dh.addStudent(sC);
        }
    }
}