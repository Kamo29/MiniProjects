﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data;
using MilesStone1.PresentationLayer;

namespace MilesStone1.DataLayer
{
    class DataHandler
    {
        string connect = @"Data Source=NIGGUS\SQLEXPRESS;Initial Catalog=StudentsDB;Integrated Security=True";

        SqlDataAdapter adapt;
        StudentForm stud = new StudentForm();
        //There will be code for the SQL connections

        //STORED PROCEDURE ARE THE QUERIES IN THE SQL INSTEAD OF HERE IN VS CODE
        public DataTable showStudentData()//open the connection to the database with their commands
        {
            SqlConnection conn = new SqlConnection(connect);
            adapt = new SqlDataAdapter("GetStudents", conn);
            adapt.SelectCommand.CommandType = CommandType.StoredProcedure;

            DataTable dt = new DataTable();
            adapt.Fill(dt);

            return dt;

            //OR

            string query = $"SELECT* FROM tblStudents";

            try
            {
                using (SqlConnection con = new SqlConnection(connect))
                {
                    using (SqlCommand command = new SqlCommand(query, con))
                    {
                        con.Open();
                        command.ExecuteNonQuery();
                        con.Close();
                    }
                }
            }

            catch (Exception e)
            {
                Console.WriteLine(e.Message);
                Console.WriteLine("Error in connecting with database");
            }
        }

        public void addStudent(StudentClass student)
        {
            string query = $"INSERT INTO tblStudents VALUES StudentName = {student.SName}, StudentSurname = {student.SName}, StudentDOB = {student.Dob}, StudentPhoneNum = {student.Phone}, StudentAddress = {student.Address}, ModuleCode = {student.ModCode} WHERE StudentName = {student.SName}";


            try
            {
                using (SqlConnection con = new SqlConnection(connect))
                {
                    using (SqlCommand command = new SqlCommand(query, con))
                    {
                        con.Open();
                        command.ExecuteNonQuery();
                        con.Close();
                    }
                }
            }

            catch (Exception e)
            {
                Console.WriteLine(e.Message);
                Console.WriteLine("Error in connecting with database");
            }
        }

        public void updataStudentData(StudentClass student)//open the connection to the database with their commands
        {
            string query = $"UPDATE tblStudents SET StudentName = {student.SName}, StudentSurname = {student.SName}, StudentDOB = {student.Dob}, StudentPhoneNum = {student.Phone}, StudentAddress = {student.Address}, ModuleCode = {student.ModCode} WHERE StudentName = {student.SName}";
                

            try
            {
                using (SqlConnection con = new SqlConnection(connect))
                {
                    using (SqlCommand command = new SqlCommand(query, con))
                    {
                        con.Open();
                        command.ExecuteNonQuery();
                        con.Close();
                    }
                }
            }

            catch (Exception e)
            {
                Console.WriteLine(e.Message);
                Console.WriteLine("Error in connecting with database");
            }
        }

        public void delStudentData(StudentClass student)//open the connection to the database with their commands
        {
            string query = $"DELETE* FROM tblStudents WHERE StudentName = {student.SName}";

            try
            {
                using (SqlConnection con = new SqlConnection(connect))
                {
                    using (SqlCommand command = new SqlCommand(query, con))
                    {
                        con.Open();
                        command.ExecuteNonQuery();
                        con.Close();
                    }
                }
            }

            catch (Exception e)
            {
                Console.WriteLine(e.Message);
                Console.WriteLine("Error in connecting with database");
            }
        }

        public void showModData()//open the connection to the database with their commands
        {
            string query = $"SELECT* FROM tblModulez";

            try
            {
                using (SqlConnection con = new SqlConnection(connect))
                {
                    using (SqlCommand command = new SqlCommand(query, con))
                    {
                        con.Open();
                        command.ExecuteNonQuery();
                        con.Close();
                    }
                }
            }

            catch (Exception e)
            {
                Console.WriteLine(e.Message);
                Console.WriteLine("Error in connecting with database");
            }
        }

        public void updataModData(ModuleClass mod)//open the connection to the database with their commands
        {
            string query = $"UPDATE tblModulez SET ModuleCode = {mod.ModCode}, ModuleName = {mod.ModName}, ModuleResources = {mod.Resources} WHERE ModuleName = {mod.ModName}";

            try
            {
                using (SqlConnection con = new SqlConnection(connect))
                {
                    using (SqlCommand command = new SqlCommand(query, con))
                    {
                        con.Open();
                        command.ExecuteNonQuery();
                        con.Close();
                    }
                }
            }

            catch (Exception e)
            {
                Console.WriteLine(e.Message);
                Console.WriteLine("Error in connecting with database");
            }
        }

        public void delModData(ModuleClass mod)//open the connection to the database with their commands
        {
            string query = $"DELETE* FROM tblModulez WHERE ModuleName = {mod.ModName}";

            try
            {
                using (SqlConnection con = new SqlConnection(connect))
                {
                    using (SqlCommand command = new SqlCommand(query, con))
                    {
                        con.Open();
                        command.ExecuteNonQuery();
                        con.Close();
                    }
                }
            }

            catch (Exception e)
            {
                Console.WriteLine(e.Message);
                Console.WriteLine("Error in connecting with database");
            }
        }

        DataTable tbl;
        public DataTable search(StudentClass student)
        {
            string query = $"SELECT & FROM tblStudents WHERE StudentName = {student.SName}";

            adapt = new SqlDataAdapter(query, connect);

            tbl = new DataTable();

            adapt.Fill(tbl);

            return tbl;
        }
    }
}
