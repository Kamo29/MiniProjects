﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using MilesStone1.DataLayer; 

namespace MilesStone1.DataAccessLayer
{
    class FileHandler
    {
        string path = @".txt";//if we need a text file

        public void writeTo(List<StudentClass> students)
        {
            using (StreamWriter sW = new StreamWriter(path))
            {
                foreach (StudentClass student in students)
                {
                    sW.WriteLine($"{student.SName}, {student.SSname}, {student.SNum}, {student.Dob}, {student.Phone}, {student.ModCode}, {student.Address}");
                }
            }
        }

        public List<string> readFrom()
        {
            List<string> people = new List<string>();
            people = File.ReadAllLines(path).ToList();

            foreach (string line in people)
            {
                Console.WriteLine(line);
            }

            return people;
        }
    }
}
