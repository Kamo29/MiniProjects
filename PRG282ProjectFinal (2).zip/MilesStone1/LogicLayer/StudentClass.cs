﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MilesStone1.DataLayer
{
    public class StudentClass
    {
        //private int sID;
        private int sNum;
        private string sName;
        private string sSname;
        private DateTime dob;
        private int phone;
        private string address;
        private string modCode;

        public StudentClass()
        {

        }
        public StudentClass(int sNum, string sName, string sSname, DateTime dob, int phone, string address, string modCode)
        {
            this.sNum = sNum;
            this.sName = sName;
            this.sSname = sSname;
            this.dob = dob;
            this.phone = phone;
            this.address = address;
            this.modCode = modCode;
        }

        //public StudentClass(int sNum, string sName, string sSname, DateTime dob, int phone, string address, string modCode)
        //{
        //    //this.SID = sID;
        //    this.sNum = sNum;
        //    this.sName = sName;
        //    this.sSname = sSname;
        //    this.dob = dob;
        //    this.phone = phone;
        //    this.address = address;
        //    this.modCode = modCode;
        //}

        public int SNum { get => sNum; set => sNum = value; }
        public string SName { get => sName; set => sName = value; }
        public string SSname { get => sSname; set => sSname = value; }
        public DateTime Dob { get => dob; set => dob = value; }
        public int Phone { get => phone; set => phone = value; }
        public string Address { get => address; set => address = value; }
        public string ModCode { get => modCode; set => modCode = value; }
        //public int SID { get => sID; set => sID = value; }

        public override string ToString()
        {
            return base.ToString();
        }
    }   
}
