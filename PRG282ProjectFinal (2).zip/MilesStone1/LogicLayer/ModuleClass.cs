﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MilesStone1.DataLayer
{
    public class ModuleClass
    {
        private string modCode;
        private string modName;
        private string resources;

        public ModuleClass(string modCode, string modName, string resources)
        {
            this.modCode = modCode;
            this.modName = modName;
            this.resources = resources;
        }

        public string ModCode { get => modCode; set => modCode = value; }
        public string ModName { get => modName; set => modName = value; }
        public string Resources { get => resources; set => resources = value; }

        public override string ToString()
        {
            return base.ToString();
        }
    }
}
